/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class SupervisorUploadTheDetailsOfRefugeeController implements Initializable {

    @FXML
    private TextField idTxt;
    @FXML
    private TextField nameTxt;
    @FXML
    private TextField serialNofxid;
    @FXML
    private TextField namefxid;
    @FXML
    private DatePicker Datepicker;
    @FXML
    private Label textlevel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    


  
    //camp instracxtoe
   

    @FXML
    private void submitButtonOnClick(ActionEvent event) {
         Supervisor stud = new Supervisor(  
                    Integer.parseInt(serialNofxid.getText()),
                    namefxid.getText(),
                    Datepicker.getValue()  
                );
        serialNofxid.setText(null);    namefxid.setText(null); 
         textlevel.setText("Information Add Successfully");
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("RefugeeInfo.bin"));
            oos.writeObject(stud);
            oos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
}
