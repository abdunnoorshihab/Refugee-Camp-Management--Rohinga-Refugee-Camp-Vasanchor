/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class SupplierReceivedMedicineInformationFromMFController implements Initializable {

    @FXML
    private TextArea ReceivedTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void clickViewMedicineInformationButton(ActionEvent event) {
        
        ReceivedTextArea.setText("");
        File f = null;
        FileInputStream fis = null;
        //BufferedInputStream bis = null;
        DataInputStream dis = null;
        String str="";
        try {
            f = new File("MedicineInformation.bin");
            if(!f.exists()){
                ReceivedTextArea.setText("No Information added!");
            }
            else{
                
                fis = new FileInputStream(f);
                dis = new DataInputStream(fis);
                //String str="";
                while(true){
                    str+= "Medecine Name: "+dis.readUTF()+"\n";                 
                }
                //outputTextArea.setText(str);
            }//else
        } catch (IOException ex) {
            ReceivedTextArea.setText(str);
            Logger.getLogger(SupplierReceivedMedicineInformationFromMFController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(dis != null) dis.close();
            } catch (IOException ex) {
                Logger.getLogger(SupplierReceivedMedicineInformationFromMFController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }          
    }
        
 }
    

