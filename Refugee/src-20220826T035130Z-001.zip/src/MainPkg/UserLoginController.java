/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;


import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author USER
 */
public class UserLoginController implements Initializable {
     
    
    @FXML
    private Label label;
    @FXML
    private TextField userPassword;
   
    @FXML
    private TextField userName;
    
    @FXML
    private ComboBox allUserInComboBox;
    @FXML
    private Label loginLabel;
    
    
    /*private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }*/
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
         allUserInComboBox.getItems().add("Camp Instractor");
      allUserInComboBox.getItems().addAll("Supervisor","Medicall Stuff","Supplier","Refugees");
      allUserInComboBox.setValue("Select User"); 
        // TODO
    }  
  

    @FXML
    private void clickLogInButtonOnAction(ActionEvent event) {
        
         String name = userName.getText().toString();
        String password = userPassword.getText().toString();
        String users = allUserInComboBox.getValue().toString();
        
        
        File logindata = null;
        FileInputStream loginInput = null;
        BufferedInputStream BufferInput = null;
        DataInputStream DataInput = null;
        String str="";
        try {
            logindata = new File("login.bin");
            if(!logindata.exists()){
                loginLabel.setText("Oops! something went wrong!!");
            }
            else{
                
                loginInput = new FileInputStream(logindata);
               
                DataInput = new DataInputStream(loginInput);
               
                while(true){
                    
                      String DataName=  DataInput.readUTF();
                       String DataPass= DataInput.readUTF();
                      String UserType=  DataInput.readUTF();
                      
                      if(DataName.equals(name) && DataPass.equals(password) && UserType.equals(users))
                      {
                          loginLabel.setText("Login Successfull!");
                          
                          if(UserType.equals("Camp Instractor"))
                          {
                               Parent scene2Parent = FXMLLoader.load(getClass().getResource("CampInstructor.fxml"));
                          Scene scene2 = new Scene(scene2Parent);
                       Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
                   window.setScene(scene2);
                      window.show();
                              
                          }
                          
                          else if(UserType.equals("Supervisor"))
                          {
                                   Parent scene2Parent = FXMLLoader.load(getClass().getResource("Supervisor.fxml"));
                          Scene scene2 = new Scene(scene2Parent);
                       Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
                   window.setScene(scene2);
                      window.show();
                              
                          }    
                          else if(UserType.equals("Medicall Stuff"))
                          {
                                   Parent scene2Parent = FXMLLoader.load(getClass().getResource("MedicalStaff.fxml"));
                          Scene scene2 = new Scene(scene2Parent);
                       Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
                   window.setScene(scene2);
                      window.show();
                              
                          }
                          
                       
                          else if(UserType.equals("Supplier"))
                          {
                           Parent scene2Parent = FXMLLoader.load(getClass().getResource("Supplier.fxml"));
                          Scene scene2 = new Scene(scene2Parent);
                         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
                   window.setScene(scene2);
                      window.show();
                              
                          }
                          else if(UserType.equals("Refugees"))
                          {
                           Parent scene2Parent = FXMLLoader.load(getClass().getResource("Refugees.fxml"));
                          Scene scene2 = new Scene(scene2Parent);
                          Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
                          window.setScene(scene2);
                          window.show();
                              
                          }
                                                 
                          break;
                      }
                    
                }//while
                //outputTextArea.setText(str);
            }//else
        } catch (Exception ex) {
            loginLabel.setText("Login Failed!");

        } finally {
          
        }   
    
    }

    @FXML
    private void clickSignUpButtonOnAction(ActionEvent event) throws IOException {
         Parent GoBackParent = FXMLLoader.load(getClass().getResource("SignUp.fxml"));
            Scene s = new Scene(GoBackParent);
          
            
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(s);
            window.show();
    }
}
   /* private class deptLabel {

        private static void setText(String string) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        public deptLabel() {
        }
    }
    
}*/
