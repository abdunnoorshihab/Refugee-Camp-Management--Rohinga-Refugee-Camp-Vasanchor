/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class MedicalStaffViewAppoinmentFromRefugeeController implements Initializable {

    @FXML
    private TextArea ReadTextFXID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void clickViewAppoinmentButton(ActionEvent event) {
        ReadTextFXID.setText("");
        File f = null;
        FileInputStream fis = null;
        //BufferedInputStream bis = null;
        DataInputStream dis = null;
        String str="";
        try {
            f = new File("Appoinment.bin");
            if(!f.exists()){
                ReadTextFXID.setText("No Request Exist!");
            }
            else{
                
                fis = new FileInputStream(f);
                dis = new DataInputStream(fis);
             
                while(true){
                    str+= "New Appoinment Received\n"+"\nPatient Name:"+dis.readUTF()
                        +";\nPatient Decease:"+dis.readUTF()
                              +"; \nPatient Message:"+dis.readUTF();
                    
                }
            }//else
        } catch (IOException ex) {
            ReadTextFXID.setText(str);
            Logger.getLogger(MedicalStaffViewAppoinmentFromRefugeeController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(dis != null) dis.close();
            } catch (IOException ex) {
                Logger.getLogger(MedicalStaffViewAppoinmentFromRefugeeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }          
    }
}
