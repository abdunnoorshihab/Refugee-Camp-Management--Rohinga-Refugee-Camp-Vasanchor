/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class MedicalStaffController implements Initializable {

    @FXML
    private BorderPane medicalStaffFXID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    private void loadMedicalStaffMultiScenes(String ui) {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource(ui+".fxml"));
            medicalStaffFXID.setCenter(root);
        } catch (IOException ex) {
            Logger.getLogger(CampInstructorController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
   
    @FXML
    private void clickappoinmentRequestFromRefugee(ActionEvent event) {
        loadMedicalStaffMultiScenes("MedicalStaffViewAppoinmentFromRefugee");
    }

    @FXML
    private void clickAnEmmergencyMessageFromRefugee(ActionEvent event) {
        loadMedicalStaffMultiScenes("MedicalStaffViewEmmergencyMessage");
    }

    @FXML
    private void provideMedicineInformationToSupplier(ActionEvent event) {
        loadMedicalStaffMultiScenes("MedicalStaffProvideMedicineInformation");
    }
    
    
    @FXML
    private void clickBacktoHomeScene(ActionEvent event) throws IOException {
        Parent GoBackParent = FXMLLoader.load(getClass().getResource("MedicalStaff.fxml"));
            Scene s = new Scene(GoBackParent);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(s);
            window.show();
    }

    @FXML
    private void clickLogoutButton(ActionEvent event) throws IOException {
        Parent GoBackParent = FXMLLoader.load(getClass().getResource("UserLogin.fxml"));
            Scene s = new Scene(GoBackParent);
          
            
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(s);
            window.show();
    }
    
}
