/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class SupervisorviewTheUpdatePriceListfromSupplierController implements Initializable {

    @FXML
    private TextArea viewTextArea;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void viewUpdatePriceListButton(ActionEvent event) {
         viewTextArea.setText("");
        File f = null;
        FileInputStream readFile = null;
        DataInputStream readData = null;
        String Project="";
        try {
            f = new File("UpdatePriceList.bin");
            if(!f.exists()){
                viewTextArea.setText("No Received price list yet!!");
            }
            else{
                
                readFile = new FileInputStream(f);

                readData = new DataInputStream(readFile);
             
                while(true){
               
               Project =  "Received Price List : \n \n"
                        + readData.readUTF()+"\n"
                        ;
                    viewTextArea.appendText(Project);
                }
            }
        } catch (IOException ex) {
           
            Logger.getLogger(SupervisorviewTheUpdatePriceListfromSupplierController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if(readData != null) readData.close();
            } catch (IOException ex) {
                Logger.getLogger(SupervisorviewTheUpdatePriceListfromSupplierController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}  

