/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class CampInstractorViewRefugeeInformationController implements Initializable {

    @FXML
    private TableView<Supervisor> fulltable;
    @FXML
    private TableColumn<Supervisor, String> serialNo;
    @FXML
    private TableColumn<Supervisor, String> Name;
    @FXML
    private TableColumn<Supervisor, LocalDate> DateOfJoining;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        serialNo.setCellValueFactory(new PropertyValueFactory<Supervisor,String>("serialNo"));
        Name.setCellValueFactory(new PropertyValueFactory<Supervisor,String>("Name"));
        DateOfJoining.setCellValueFactory(new PropertyValueFactory<Supervisor,LocalDate>("doj"));
    }    

    @FXML
    private void ViewRefudeeDetailes(ActionEvent event) {
          ObjectInputStream ois=null;
         try {
            Supervisor s;
            ois = new ObjectInputStream(new FileInputStream("RefugeeInfo.bin"));
            s = (Supervisor) ois.readObject();
          
            fulltable.getItems().add(s);
            
            
        } catch (Exception ex) {
            try {
                if(ois!=null)
                    ois.close();
            } 
            catch (IOException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        }
    }
    
}
