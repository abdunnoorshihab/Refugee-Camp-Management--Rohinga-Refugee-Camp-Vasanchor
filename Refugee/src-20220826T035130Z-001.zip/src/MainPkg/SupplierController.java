/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class SupplierController implements Initializable {

    @FXML
    private BorderPane SupplierFXID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }  
    private void loadSupplierMultiScenes(String ui) {
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource(ui+".fxml"));
            SupplierFXID.setCenter(root);
        } catch (IOException ex) {
            Logger.getLogger(CampInstructorController.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }

    @FXML
    private void clickButtonOnDemandList(ActionEvent event) {
        loadSupplierMultiScenes("SupplierFollowtheDemandList");
    }

    @FXML
    private void clickButtonOnPriceList(ActionEvent event) {
         loadSupplierMultiScenes("SupplierUpdateThePricelist");
    }

    @FXML
    private void receivedMedicineInformationfromSupervisor(ActionEvent event) {
         loadSupplierMultiScenes("SupplierReceivedMedicineInformationFromMS");
    }

    
    @FXML
    private void clickBackToHomeSceneButton(ActionEvent event) throws IOException {
        Parent GoBackParent = FXMLLoader.load(getClass().getResource("Supplier.fxml"));
            Scene s = new Scene(GoBackParent);

            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(s);
            window.show();
    }
    
    @FXML
    private void clickLogoutButton(ActionEvent event) throws IOException {
        Parent GoBackParent = FXMLLoader.load(getClass().getResource("UserLogin.fxml"));
            Scene s = new Scene(GoBackParent);
          
            
            Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
            
            window.setScene(s);
            window.show();
    }
    
}
