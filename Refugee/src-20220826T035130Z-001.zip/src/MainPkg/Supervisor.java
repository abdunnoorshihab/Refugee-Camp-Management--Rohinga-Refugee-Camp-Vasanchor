/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainPkg;

import java.io.Serializable;
import java.time.LocalDate;

/**
 *
 * @author USER
 */
public class Supervisor implements Serializable {
    protected int serialNo;
    protected String Name;
    protected LocalDate doj;

    public Supervisor(int serialNo, String Name, LocalDate doj) {
        this.serialNo = serialNo;
        this.Name = Name;
        this.doj = doj;
    }

    public int getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(int serialNo) {
        this.serialNo = serialNo;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public LocalDate getDoj() {
        return doj;
    }

    public void setDoj(LocalDate doj) {
        this.doj = doj;
    }

    @Override
    public String toString() {
        return "Supervisor{" + "serialNo=" + serialNo + ", Name=" + Name + ", doj=" + doj + '}';
    }
    
            
    
}
